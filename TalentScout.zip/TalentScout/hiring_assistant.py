
# hiring_assistant.py
import streamlit as st
import openai
import os

# Set your OpenAI API key
openai.api_key = os.getenv("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")  # Use environment variable or replace with your key for testing

st.set_page_config(page_title="TalentScout Hiring Assistant", layout="centered")
st.title(" TalentScout - Hiring Assistant Chatbot")

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "system", "content": "You are a helpful hiring assistant AI for a tech recruitment agency. Greet the user, collect candidate information, and generate 3-5 technical questions based on the declared tech stack."}
    ]

st.markdown("""
This chatbot will collect your basic information and ask technical questions based on your tech stack.
Type **'exit'** to end the conversation.
""")

# Chat interface
user_input = st.text_input("You:", key="user_input")

if user_input:
    if user_input.lower() in ["exit", "quit", "bye"]:
        st.session_state.messages.append({"role": "user", "content": user_input})
        st.session_state.messages.append({"role": "assistant", "content": "Thank you for your time! We'll be in touch soon. 👋"})
    else:
        st.session_state.messages.append({"role": "user", "content": user_input})

        # LLM call to OpenAI
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",  # Or gpt-4 if you have access
                messages=st.session_state.messages,
                temperature=0.5,
            )
            reply = response["choices"][0]["message"]["content"]
            st.session_state.messages.append({"role": "assistant", "content": reply})
        except Exception as e:
            reply = f"Error: {str(e)}"
            st.session_state.messages.append({"role": "assistant", "content": reply})

# Display the conversation
for message in st.session_state.messages[1:]:
    if message["role"] == "user":
        st.markdown(f"**You:** {message['content']}")
    else:
        st.markdown(f"**Assistant:** {message['content']}")
