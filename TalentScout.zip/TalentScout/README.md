
# TalentScout Hiring Assistant Chatbot

This is a Streamlit-based chatbot designed to act as a Hiring Assistant for a tech recruitment agency.

##  Features
- Collects candidate information (name, email, experience, tech stack, etc.)
- Generates 3-5 technical questions based on the provided tech stack (e.g., Python, Django)
- Handles conversation context and ends gracefully
- Built using OpenAI GPT and Streamlit

##  How to Run
1. Make sure you have Python 3.7+ installed.
2. Install dependencies:
   ```bash
   pip install streamlit openai
   ```
3. Set your OpenAI API key:
   ```bash
   export OPENAI_API_KEY=your_key_here
   ```
4. Run the app:
   ```bash
   streamlit run hiring_assistant.py
   ```

##  Files
- `hiring_assistant.py` – Main Streamlit chatbot code
- `README.md` – Project overview and setup instructions

##  Notes
- Designed to run locally.
- You can add more logic to store responses, enhance UI, or deploy to cloud.
